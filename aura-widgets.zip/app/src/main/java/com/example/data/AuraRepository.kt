package com.example.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import com.example.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Locale

class AuraRepository(private val context: Context) {

    private val prefs = context.getSharedPreferences("aura_widget_prefs", Context.MODE_PRIVATE)

    companion object {
        @Volatile
        private var instance: AuraRepository? = null

        fun getInstance(context: Context): AuraRepository {
            return instance ?: synchronized(this) {
                instance ?: AuraRepository(context.applicationContext).also { instance = it }
            }
        }

        // Widget Dimension Specifications according to mandatory revision
        val WIDGET_SPECS = listOf(
            WidgetDimensionSpec(
                id = "calendar",
                name = "Monthly Calendar",
                preferredCellSpan = "4×3",
                defaultCols = 4,
                defaultRows = 3,
                minWidthDp = 250,
                minHeightDp = 180,
                minResizeWidthDp = 180,
                minResizeHeightDp = 120,
                description = "Medium-sized, complete month calendar with Monday-first columns, 6-week support, and subtle today highlight.",
                sizingRules = listOf(
                    "Preferred default: 4×3 cells (not oversized)",
                    "Seven weekday columns with Monday-first",
                    "All dates visible including six-week months",
                    "Month & year in small elegant heading",
                    "No additional tasks or unnecessary clutter",
                    "Supports resizing to larger or compact sizes"
                )
            ),
            WidgetDimensionSpec(
                id = "luxury_clock",
                name = "Luxury Analogue Clock",
                preferredCellSpan = "2×2",
                defaultCols = 2,
                defaultRows = 2,
                minWidthDp = 110,
                minHeightDp = 110,
                minResizeWidthDp = 90,
                minResizeHeightDp = 90,
                description = "Ultra-compact watch-style dial centered with thin hands, refined markings, and sapphire glass appearance.",
                sizingRules = listOf(
                    "Preferred default: 2×2 cells (must be small)",
                    "Show ONLY the analogue clock",
                    "NO date, NO weather, NO city name, NO digital clock",
                    "NO large surrounding card or bulky borders",
                    "Retains minimal clock-only design at every size"
                )
            ),
            WidgetDimensionSpec(
                id = "photo_frame",
                name = "Living Photo Frame",
                preferredCellSpan = "2×2",
                defaultCols = 2,
                defaultRows = 2,
                minWidthDp = 110,
                minHeightDp = 110,
                minResizeWidthDp = 90,
                minResizeHeightDp = 90,
                description = "Compact square photo frame showcasing photographs prominently with intelligent crop and subtle date caption.",
                sizingRules = listOf(
                    "Preferred default: 2×2 cells",
                    "Display selected photograph prominently",
                    "Avoid oversized borders, optional tiny date caption",
                    "Intelligent center/subject crop",
                    "Tap to advance slideshow / pause",
                    "Adapts cleanly when resized to 3×2 or larger"
                )
            ),
            WidgetDimensionSpec(
                id = "world_clock",
                name = "World Clock",
                preferredCellSpan = "3×2",
                defaultCols = 3,
                defaultRows = 2,
                minWidthDp = 180,
                minHeightDp = 110,
                minResizeWidthDp = 140,
                minResizeHeightDp = 90,
                description = "Compact 4-city time display for India, London, New York and Singapore with day/night indicator and date difference.",
                sizingRules = listOf(
                    "Preferred default: 3×2 cells",
                    "Four default cities: India, London, New York, Singapore",
                    "City name, local time, small day/night symbol",
                    "Date shown only when different from India (e.g. -1d / +1d)",
                    "Avoid large decorative clocks or excessive spacing",
                    "Compact 2x2 grid or responsive multi-column layout"
                )
            ),
            WidgetDimensionSpec(
                id = "weather",
                name = "Weather",
                preferredCellSpan = "3×2",
                defaultCols = 3,
                defaultRows = 2,
                minWidthDp = 180,
                minHeightDp = 110,
                minResizeWidthDp = 140,
                minResizeHeightDp = 90,
                description = "Medium-sized horizontal weather layout with current conditions on the left and 3-day forecast on the right.",
                sizingRules = listOf(
                    "Preferred default: 3×2 cells (horizontal split)",
                    "Left: Current temp, small icon, condition, today's H/L",
                    "Right: 3-day forecast with day labels, icons, H/L, rain %",
                    "Concise typography, tight comfortable spacing",
                    "NO oversized illustrations or hourly forecast charts",
                    "Adapts gracefully if resized to 2×2 or 4×2"
                )
            )
        )
    }

    // -------------------------------------------------------------
    // 1. CALENDAR DATA
    // -------------------------------------------------------------
    fun getCalendarData(targetDate: LocalDate = LocalDate.now()): CalendarGridData {
        val year = targetDate.year
        val month = targetDate.month
        val monthName = month.getDisplayName(java.time.format.TextStyle.FULL, Locale.ENGLISH)
        val daysInMonth = targetDate.lengthOfMonth()

        val firstDayOfMonth = targetDate.withDayOfMonth(1)
        // DayOfWeek: 1 = Monday, 7 = Sunday -> 0..6
        val startDayOfWeekMondayBased = firstDayOfMonth.dayOfWeek.value - 1

        val totalCellsNeeded = startDayOfWeekMondayBased + daysInMonth
        val totalRowsNeeded = if (totalCellsNeeded > 35) 6 else 5

        return CalendarGridData(
            year = year,
            monthName = monthName,
            daysInMonth = daysInMonth,
            startDayOfWeekMondayBased = startDayOfWeekMondayBased,
            todayDayOfMonth = if (targetDate.year == LocalDate.now().year && targetDate.month == LocalDate.now().month) {
                targetDate.dayOfMonth
            } else -1,
            totalRowsNeeded = totalRowsNeeded
        )
    }

    // -------------------------------------------------------------
    // 2. WORLD CLOCK DATA (India, London, New York, Singapore)
    // -------------------------------------------------------------
    fun getDefaultCities(): List<CityTimeInfo> {
        return listOf(
            CityTimeInfo("India", "IST", "Asia/Kolkata", isReferenceCity = true),
            CityTimeInfo("London", "UK", "Europe/London"),
            CityTimeInfo("New York", "USA", "America/New_York"),
            CityTimeInfo("Singapore", "SG", "Asia/Singapore")
        )
    }

    data class CityTimeResult(
        val cityName: String,
        val formattedTime: String,
        val isDaytime: Boolean,
        val dayOffsetStr: String?,
        val timeZoneAbbr: String
    )

    fun getCityTimeResults(): List<CityTimeResult> {
        val now = Instant.now()
        val indiaZone = ZoneId.of("Asia/Kolkata")
        val indiaZoned = ZonedDateTime.ofInstant(now, indiaZone)
        val indiaDate = indiaZoned.toLocalDate()

        val cities = getDefaultCities()
        val timeFormatter = DateTimeFormatter.ofPattern("HH:mm", Locale.ENGLISH)

        return cities.map { city ->
            val zone = ZoneId.of(city.timeZoneId)
            val cityZoned = ZonedDateTime.ofInstant(now, zone)
            val cityDate = cityZoned.toLocalDate()

            val hour = cityZoned.hour
            val isDaytime = hour in 6..18
            val formattedTime = cityZoned.format(timeFormatter)

            val dayDiff = ChronoUnit.DAYS.between(indiaDate, cityDate)
            val dayOffsetStr = when {
                dayDiff < 0 -> "-1d"
                dayDiff > 0 -> "+1d"
                else -> null
            }

            CityTimeResult(
                cityName = city.cityName,
                formattedTime = formattedTime,
                isDaytime = isDaytime,
                dayOffsetStr = dayOffsetStr,
                timeZoneAbbr = city.country
            )
        }
    }

    // -------------------------------------------------------------
    // 3. WEATHER DATA & INTEGRATION
    // -------------------------------------------------------------
    fun getWeatherData(): WeatherInfo {
        val city = prefs.getString("weather_city", "Bengaluru") ?: "Bengaluru"
        val currentTemp = prefs.getInt("weather_temp", 26)
        val condition = prefs.getString("weather_cond", "Partly Cloudy") ?: "Partly Cloudy"
        val high = currentTemp + 3
        val low = currentTemp - 6

        val forecast = listOf(
            DayForecast("Mon", WeatherIconType.PARTLY_CLOUDY, highTempC = currentTemp + 2, lowTempC = currentTemp - 5, rainProb = 15),
            DayForecast("Tue", WeatherIconType.SUNNY, highTempC = currentTemp + 4, lowTempC = currentTemp - 4, rainProb = 5),
            DayForecast("Wed", WeatherIconType.RAINY, highTempC = currentTemp, lowTempC = currentTemp - 7, rainProb = 65)
        )

        return WeatherInfo(
            cityName = city,
            currentTempC = currentTemp,
            condition = condition,
            highTempC = high,
            lowTempC = low,
            humidity = 64,
            rainProb = 20,
            iconType = parseWeatherIcon(condition),
            forecast = forecast
        )
    }

    fun updateWeatherSettings(city: String, temp: Int, condition: String) {
        prefs.edit()
            .putString("weather_city", city)
            .putInt("weather_temp", temp)
            .putString("weather_cond", condition)
            .apply()
    }

    private fun parseWeatherIcon(condition: String): WeatherIconType {
        val lower = condition.lowercase()
        return when {
            lower.contains("rain") -> WeatherIconType.RAINY
            lower.contains("cloud") -> WeatherIconType.PARTLY_CLOUDY
            lower.contains("storm") -> WeatherIconType.THUNDERSTORM
            else -> WeatherIconType.SUNNY
        }
    }

    suspend fun refreshLiveWeather(): Boolean = withContext(Dispatchers.IO) {
        try {
            // Open-Meteo free live API for Bengaluru coordinates (12.97, 77.59)
            val urlString = "https://api.open-meteo.com/v1/forecast?latitude=12.97&longitude=77.59&current=temperature_2m,relative_humidity_2m,weather_code&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max&timezone=auto"
            val url = URL(urlString)
            val connection = url.openConnection() as HttpURLConnection
            connection.connectTimeout = 4000
            connection.readTimeout = 4000

            if (connection.responseCode == 200) {
                val responseText = connection.inputStream.bufferedReader().use { it.readText() }
                val json = JSONObject(responseText)
                val current = json.getJSONObject("current")
                val tempC = current.getDouble("temperature_2m").toInt()
                val code = current.getInt("weather_code")

                val condition = when (code) {
                    0 -> "Clear Sky"
                    1, 2, 3 -> "Partly Cloudy"
                    51, 53, 55, 61, 63, 65 -> "Showers"
                    80, 81, 82 -> "Rainy"
                    95, 96, 99 -> "Thunderstorm"
                    else -> "Fair"
                }

                updateWeatherSettings("Bengaluru", tempC, condition)
                return@withContext true
            }
        } catch (e: Exception) {
            // Graceful fallback to simulated values
        }
        return@withContext false
    }

    // -------------------------------------------------------------
    // 4. LIVING PHOTO FRAME (Curated + Custom User Photos)
    // -------------------------------------------------------------
    val curatedPhotos = listOf(
        CuratedPhoto("arch_1", "Minimal Pavilion", "OCT 2026", 0xFF1E293B),
        CuratedPhoto("nature_1", "Misty Nordic Pines", "SEP 2026", 0xFF0F2922),
        CuratedPhoto("sunset_1", "Alpine Golden Hour", "OCT 2026", 0xFF3D1F14),
        CuratedPhoto("tokyo_1", "Kyoto Bamboo Garden", "AUG 2026", 0xFF132A1C),
        CuratedPhoto("glass_1", "HyperOS Obsidian Glass", "NOV 2026", 0xFF0A0F1D)
    )

    private val customPhotoFile: File
        get() = File(context.filesDir, "aura_custom_photo.jpg")

    fun hasCustomPhoto(): Boolean = customPhotoFile.exists() && customPhotoFile.length() > 0

    fun getCustomPhotoBitmap(): Bitmap? {
        return if (hasCustomPhoto()) {
            BitmapFactory.decodeFile(customPhotoFile.absolutePath)
        } else null
    }

    fun saveCustomPhoto(uri: Uri): Boolean {
        return try {
            val inputStream: InputStream? = context.contentResolver.openInputStream(uri)
            inputStream?.use { input ->
                FileOutputStream(customPhotoFile).use { output ->
                    input.copyTo(output)
                }
            }
            prefs.edit().putBoolean("use_custom_photo", true).apply()
            true
        } catch (e: Exception) {
            false
        }
    }

    fun isUsingCustomPhoto(): Boolean {
        return prefs.getBoolean("use_custom_photo", false) && hasCustomPhoto()
    }

    fun toggleUseCustomPhoto(enable: Boolean) {
        prefs.edit().putBoolean("use_custom_photo", enable).apply()
    }

    fun getCurrentPhotoIndex(): Int {
        return prefs.getInt("photo_index", 0) % curatedPhotos.size
    }

    fun advancePhoto(): CuratedPhoto {
        val next = (getCurrentPhotoIndex() + 1) % curatedPhotos.size
        prefs.edit().putInt("photo_index", next).apply()
        return curatedPhotos[next]
    }

    // -------------------------------------------------------------
    // 5. CLOCK DIAL THEME
    // -------------------------------------------------------------
    fun getClockDialTheme(): ClockDialTheme {
        val name = prefs.getString("clock_theme", ClockDialTheme.OBSIDIAN_GOLD.name)
        return try {
            ClockDialTheme.valueOf(name ?: ClockDialTheme.OBSIDIAN_GOLD.name)
        } catch (e: Exception) {
            ClockDialTheme.OBSIDIAN_GOLD
        }
    }

    fun setClockDialTheme(theme: ClockDialTheme) {
        prefs.edit().putString("clock_theme", theme.name).apply()
    }

    // -------------------------------------------------------------
    // 6. NATIVE APP LAUNCHING ACTIONS PREFERENCES
    // -------------------------------------------------------------
    fun getWidgetTapTarget(widgetKey: String): String {
        // "aura" or "system"
        return prefs.getString("tap_target_$widgetKey", "aura") ?: "aura"
    }

    fun setWidgetTapTarget(widgetKey: String, target: String) {
        prefs.edit().putString("tap_target_$widgetKey", target).apply()
    }
}
