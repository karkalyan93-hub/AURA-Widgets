package com.example.model

data class WidgetDimensionSpec(
    val id: String,
    val name: String,
    val preferredCellSpan: String, // e.g. "4×3"
    val defaultCols: Int,
    val defaultRows: Int,
    val minWidthDp: Int,
    val minHeightDp: Int,
    val minResizeWidthDp: Int,
    val minResizeHeightDp: Int,
    val description: String,
    val sizingRules: List<String>
)

data class CityTimeInfo(
    val cityName: String,
    val country: String,
    val timeZoneId: String,
    val isReferenceCity: Boolean = false
)

data class WeatherInfo(
    val cityName: String,
    val currentTempC: Int,
    val condition: String,
    val highTempC: Int,
    val lowTempC: Int,
    val humidity: Int,
    val rainProb: Int,
    val iconType: WeatherIconType,
    val forecast: List<DayForecast>
)

data class DayForecast(
    val dayName: String,
    val iconType: WeatherIconType,
    val highTempC: Int,
    val lowTempC: Int,
    val rainProb: Int
)

enum class WeatherIconType {
    SUNNY,
    PARTLY_CLOUDY,
    CLOUDY,
    RAINY,
    THUNDERSTORM,
    NIGHT_CLEAR
}

data class CalendarGridData(
    val year: Int,
    val monthName: String,
    val daysInMonth: Int,
    val startDayOfWeekMondayBased: Int, // 0 = Mon, 6 = Sun
    val todayDayOfMonth: Int,
    val totalRowsNeeded: Int // 5 or 6 rows
)

enum class ClockDialTheme(val title: String, val dialBg: Int, val handColor: Int, val accentColor: Int) {
    OBSIDIAN_GOLD("Obsidian Gold", 0xFF0B0F19.toInt(), 0xFFF59E0B.toInt(), 0xFF38BDF8.toInt()),
    SAPPHIRE_AZURE("Sapphire Azure", 0xFF081628.toInt(), 0xFF38BDF8.toInt(), 0xFF93C5FD.toInt()),
    EMERALD_NOIR("Emerald Noir", 0xFF061A14.toInt(), 0xFF10B981.toInt(), 0xFFF59E0B.toInt()),
    CHAMPAGNE_TITANIUM("Titanium", 0xFF1E293B.toInt(), 0xFFF8FAFC.toInt(), 0xFFFCD34D.toInt())
}

data class CuratedPhoto(
    val id: String,
    val title: String,
    val dateCaption: String,
    val dominantColor: Long
)
