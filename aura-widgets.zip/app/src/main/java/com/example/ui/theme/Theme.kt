package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = AuraGold,
    onPrimary = AuraOnPrimary,
    secondary = AuraCyan,
    onSecondary = AuraOnSecondary,
    tertiary = AuraEmerald,
    background = AuraBackground,
    surface = AuraSurface,
    onBackground = AuraTextPrimary,
    onSurface = AuraTextPrimary,
    surfaceVariant = AuraSurfaceCard,
    onSurfaceVariant = AuraTextSecondary,
    outline = AuraGlassBorder
)

private val LightColorScheme = darkColorScheme(
    primary = AuraGold,
    onPrimary = AuraOnPrimary,
    secondary = AuraCyan,
    onSecondary = AuraOnSecondary,
    tertiary = AuraEmerald,
    background = Color(0xFF0F172A),
    surface = Color(0xFF1E293B),
    onBackground = AuraTextPrimary,
    onSurface = AuraTextPrimary,
    surfaceVariant = Color(0xFF334155),
    onSurfaceVariant = AuraTextSecondary,
    outline = AuraGlassBorder
)

@Composable
fun AuraTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    // AURA maintains its signature luxury glassmorphism atmosphere in both modes
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
