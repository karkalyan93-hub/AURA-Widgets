package com.example.ui

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.AlarmClock
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AuraRepository
import com.example.model.ClockDialTheme
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.widget.*
import kotlinx.coroutines.launch
import java.time.LocalDate

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuraStudioScreen(
    initialTab: String? = null
) {
    val context = LocalContext.current
    val repo = remember { AuraRepository.getInstance(context) }

    var selectedTab by remember {
        mutableStateOf(
            when (initialTab) {
                "calendar" -> 2
                "clock" -> 3
                "photo_frame" -> 4
                "world_clock" -> 5
                "weather" -> 6
                else -> 0
            }
        )
    }

    val tabTitles = listOf(
        "Desktop Sandbox",
        "Sizing Specs",
        "Calendar (4×3)",
        "Luxury Clock (2×2)",
        "Photo Frame (2×2)",
        "World Clock (3×2)",
        "Weather (3×2)"
    )

    Scaffold(
        containerColor = AuraBackground,
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF0A0F1D))
                    .statusBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "AURA",
                                color = AuraGold,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.ExtraBold,
                                letterSpacing = 2.sp
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "WIDGETS",
                                color = AuraTextPrimary,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(0x3338BDF8))
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "Xiaomi Pad 8",
                                    color = AuraCyan,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                        Text(
                            text = "Compact, elegant & space-efficient glassmorphism layout",
                            color = AuraTextSecondary,
                            fontSize = 12.sp
                        )
                    }

                    AssistChip(
                        onClick = { selectedTab = 1 },
                        label = { Text("Grid Spans", color = AuraTextPrimary, fontSize = 12.sp) },
                        leadingIcon = {
                            Icon(Icons.Default.GridView, contentDescription = null, tint = AuraGold, modifier = Modifier.size(16.dp))
                        },
                        colors = AssistChipDefaults.assistChipColors(containerColor = AuraSurfaceCard),
                        border = AssistChipDefaults.assistChipBorder(borderColor = AuraGlassBorder, enabled = true),
                        modifier = Modifier.testTag("specs_quick_btn")
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                ScrollableTabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = Color.Transparent,
                    contentColor = AuraGold,
                    divider = {},
                    edgePadding = 0.dp
                ) {
                    tabTitles.forEachIndexed { index, title ->
                        Tab(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            text = {
                                Text(
                                    text = title,
                                    fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 13.sp,
                                    color = if (selectedTab == index) AuraGold else AuraTextSecondary
                                )
                            },
                            modifier = Modifier.testTag("tab_$index")
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                0 -> DesktopSandboxScreen(repo, onPinWidget = { pinWidget(context, it) })
                1 -> SizingSpecsScreen()
                2 -> CalendarCustomizerScreen(repo, onPinWidget = { pinWidget(context, CalendarWidgetProvider::class.java) })
                3 -> ClockCustomizerScreen(repo, onPinWidget = { pinWidget(context, LuxuryClockWidgetProvider::class.java) })
                4 -> PhotoFrameCustomizerScreen(repo, onPinWidget = { pinWidget(context, PhotoFrameWidgetProvider::class.java) })
                5 -> WorldClockCustomizerScreen(repo, onPinWidget = { pinWidget(context, WorldClockWidgetProvider::class.java) })
                6 -> WeatherCustomizerScreen(repo, onPinWidget = { pinWidget(context, WeatherWidgetProvider::class.java) })
            }
        }
    }
}

// -----------------------------------------------------------------
// 1. DESKTOP SANDBOX SCREEN
// -----------------------------------------------------------------
@Composable
fun DesktopSandboxScreen(
    repo: AuraRepository,
    onPinWidget: (Class<*>) -> Unit
) {
    var calendarSpan by remember { mutableStateOf("4×3") }
    var clockSpan by remember { mutableStateOf("2×2") }
    var photoSpan by remember { mutableStateOf("2×2") }
    var worldSpan by remember { mutableStateOf("3×2") }
    var weatherSpan by remember { mutableStateOf("3×2") }

    val context = LocalContext.current

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = AuraSurfaceCard),
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.dp, AuraGlassBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .background(Color(0x33F59E0B), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = AuraGold)
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Xiaomi HyperOS Space-Efficient Layout",
                            color = AuraTextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Each widget occupies only the space required. Use the size toggles below to preview adaptive reorganizing.",
                            color = AuraTextSecondary,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        item {
            Text(
                text = "HOME SCREEN SIMULATION (PAD 8)",
                color = AuraTextMuted,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
        }

        // Row 1: Calendar (4×3) & Luxury Clock (2×2) + Photo Frame (2×2)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Calendar Card
                Column(modifier = Modifier.weight(1.3f)) {
                    WidgetHeaderBar(
                        title = "Monthly Calendar",
                        currentSpan = calendarSpan,
                        availableSpans = listOf("4×3", "3×3", "4×4"),
                        onSpanChange = { calendarSpan = it },
                        onPin = { onPinWidget(CalendarWidgetProvider::class.java) }
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    AuraCalendarWidget(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(if (calendarSpan == "4×4") 260.dp else 210.dp),
                        repo = repo,
                        cellSpan = calendarSpan
                    )
                }

                // Clock & Photo Stack (both 2×2)
                Column(
                    modifier = Modifier.weight(0.9f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Column {
                        WidgetHeaderBar(
                            title = "Luxury Clock",
                            currentSpan = clockSpan,
                            availableSpans = listOf("2×2", "3×3"),
                            onSpanChange = { clockSpan = it },
                            onPin = { onPinWidget(LuxuryClockWidgetProvider::class.java) }
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        AuraLuxuryClockWidget(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(130.dp),
                            repo = repo
                        )
                    }

                    Column {
                        WidgetHeaderBar(
                            title = "Photo Frame",
                            currentSpan = photoSpan,
                            availableSpans = listOf("2×2", "3×2"),
                            onSpanChange = { photoSpan = it },
                            onPin = { onPinWidget(PhotoFrameWidgetProvider::class.java) }
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        AuraPhotoFrameWidget(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(115.dp),
                            repo = repo,
                            onTapNext = {
                                repo.advancePhoto()
                                PhotoFrameWidgetProvider.updateAll(context)
                            }
                        )
                    }
                }
            }
        }

        // Row 2: World Clock (3×2) & Weather (3×2)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // World Clock (3×2)
                Column(modifier = Modifier.weight(1f)) {
                    WidgetHeaderBar(
                        title = "World Clock",
                        currentSpan = worldSpan,
                        availableSpans = listOf("3×2", "4×2", "2×3"),
                        onSpanChange = { worldSpan = it },
                        onPin = { onPinWidget(WorldClockWidgetProvider::class.java) }
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    AuraWorldClockWidget(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(130.dp),
                        repo = repo,
                        cellSpan = worldSpan
                    )
                }

                // Weather (3×2)
                Column(modifier = Modifier.weight(1f)) {
                    WidgetHeaderBar(
                        title = "Weather",
                        currentSpan = weatherSpan,
                        availableSpans = listOf("3×2", "2×2", "4×2"),
                        onSpanChange = { weatherSpan = it },
                        onPin = { onPinWidget(WeatherWidgetProvider::class.java) }
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    AuraWeatherWidget(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(130.dp),
                        repo = repo
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
fun WidgetHeaderBar(
    title: String,
    currentSpan: String,
    availableSpans: List<String>,
    onSpanChange: (String) -> Unit,
    onPin: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = title,
                color = AuraTextPrimary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.width(6.dp))
            availableSpans.forEach { span ->
                Box(
                    modifier = Modifier
                        .padding(horizontal = 2.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (currentSpan == span) AuraGold else Color(0x22FFFFFF))
                        .clickable { onSpanChange(span) }
                        .padding(horizontal = 4.dp, vertical = 1.dp)
                ) {
                    Text(
                        text = span,
                        color = if (currentSpan == span) Color(0xFF0F172A) else AuraTextSecondary,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        IconButton(
            onClick = onPin,
            modifier = Modifier.size(24.dp)
        ) {
            Icon(
                Icons.Default.AddCircleOutline,
                contentDescription = "Pin to Home Screen",
                tint = AuraCyan,
                modifier = Modifier.size(16.dp)
            )
        }
    }
}

// -----------------------------------------------------------------
// 2. SIZING SPECIFICATIONS MATRIX SCREEN
// -----------------------------------------------------------------
@Composable
fun SizingSpecsScreen() {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "MANDATORY DIMENSIONS & ADAPTIVE SIZING MATRIX",
                color = AuraGold,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Exact cell spans and constraints configured in appwidget-provider metadata and responsive rendering.",
                color = AuraTextSecondary,
                fontSize = 13.sp
            )
        }

        items(AuraRepository.WIDGET_SPECS) { spec ->
            Card(
                colors = CardDefaults.cardColors(containerColor = AuraSurfaceCard),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, AuraGlassBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = spec.name,
                            color = AuraTextPrimary,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0x33F59E0B))
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "Span: ${spec.preferredCellSpan}",
                                color = AuraGold,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = spec.description,
                        color = AuraTextSecondary,
                        fontSize = 13.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0x220F172A))
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        MetricItem("Default minWidth", "${spec.minWidthDp} dp")
                        MetricItem("Default minHeight", "${spec.minHeightDp} dp")
                        MetricItem("minResizeWidth", "${spec.minResizeWidthDp} dp")
                        MetricItem("minResizeHeight", "${spec.minResizeHeightDp} dp")
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Design & Resizing Rules:",
                        color = AuraCyan,
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    spec.sizingRules.forEach { rule ->
                        Row(modifier = Modifier.padding(vertical = 2.dp)) {
                            Text(text = "• ", color = AuraCyan, fontSize = 12.sp)
                            Text(text = rule, color = AuraTextPrimary, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MetricItem(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = label, color = AuraTextMuted, fontSize = 10.sp)
        Text(text = value, color = AuraTextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

// -----------------------------------------------------------------
// 3. CALENDAR CUSTOMIZER SCREEN (4×3 Preferred)
// -----------------------------------------------------------------
@Composable
fun CalendarCustomizerScreen(
    repo: AuraRepository,
    onPinWidget: () -> Unit
) {
    var selectedMonthOffset by remember { mutableStateOf(0L) }
    val displayDate = remember(selectedMonthOffset) {
        LocalDate.now().plusMonths(selectedMonthOffset)
    }
    val context = LocalContext.current
    var tapTarget by remember { mutableStateOf(repo.getWidgetTapTarget("calendar")) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = AuraSurfaceCard),
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.dp, AuraGlassBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Monthly Calendar (4×3)",
                                color = AuraTextPrimary,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Complete month, Monday-first, 6-week support, subtle today glow.",
                                color = AuraTextSecondary,
                                fontSize = 12.sp
                            )
                        }
                        Button(
                            onClick = onPinWidget,
                            colors = ButtonDefaults.buttonColors(containerColor = AuraGold),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, tint = Color(0xFF0F172A), modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Pin Widget", color = Color(0xFF0F172A), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { selectedMonthOffset-- }) {
                            Icon(Icons.Default.ChevronLeft, contentDescription = "Previous Month", tint = AuraTextPrimary)
                        }
                        Text(
                            text = "${displayDate.month} ${displayDate.year}",
                            color = AuraGold,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        IconButton(onClick = { selectedMonthOffset++ }) {
                            Icon(Icons.Default.ChevronRight, contentDescription = "Next Month", tint = AuraTextPrimary)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    AuraCalendarWidget(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(230.dp),
                        repo = repo,
                        targetDate = displayDate,
                        cellSpan = "4×3"
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = { openSystemCalendar(context) },
                            border = BorderStroke(1.dp, AuraGlassBorder),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.CalendarToday, contentDescription = null, tint = AuraCyan, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Open Native Calendar", color = AuraTextPrimary, fontSize = 12.sp)
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Tap target: ", color = AuraTextSecondary, fontSize = 12.sp)
                            FilterChip(
                                selected = tapTarget == "system",
                                onClick = {
                                    val newTarget = if (tapTarget == "system") "aura" else "system"
                                    tapTarget = newTarget
                                    repo.setWidgetTapTarget("calendar", newTarget)
                                    CalendarWidgetProvider.updateAll(context)
                                },
                                label = { Text(if (tapTarget == "system") "System App" else "AURA Studio", fontSize = 11.sp) }
                            )
                        }
                    }
                }
            }
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = AuraSurfaceCard),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, AuraGlassBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Sizing Verification Checkpoints",
                        color = AuraCyan,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("✓ Monday-first 7-column header (M T W T F S S)", color = AuraTextPrimary, fontSize = 12.sp)
                    Text("✓ All dates visible, including six-week months (e.g. August 2026)", color = AuraTextPrimary, fontSize = 12.sp)
                    Text("✓ Current date subtly highlighted with gold glow pill", color = AuraTextPrimary, fontSize = 12.sp)
                    Text("✓ Compact spacing and readable numbers without task clutter", color = AuraTextPrimary, fontSize = 12.sp)
                }
            }
        }
    }
}

// -----------------------------------------------------------------
// 4. CLOCK CUSTOMIZER SCREEN (2×2 Preferred)
// -----------------------------------------------------------------
@Composable
fun ClockCustomizerScreen(
    repo: AuraRepository,
    onPinWidget: () -> Unit
) {
    var selectedTheme by remember { mutableStateOf(repo.getClockDialTheme()) }
    val context = LocalContext.current
    var tapTarget by remember { mutableStateOf(repo.getWidgetTapTarget("clock")) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = AuraSurfaceCard),
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.dp, AuraGlassBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Luxury Analogue Clock (2×2)",
                                color = AuraTextPrimary,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Minimal clock-only dial. No date, no weather, no digital clock.",
                                color = AuraTextSecondary,
                                fontSize = 12.sp
                            )
                        }
                        Button(
                            onClick = onPinWidget,
                            colors = ButtonDefaults.buttonColors(containerColor = AuraGold),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, tint = Color(0xFF0F172A), modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Pin Widget", color = Color(0xFF0F172A), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        AuraLuxuryClockWidget(
                            modifier = Modifier.size(180.dp),
                            repo = repo,
                            dialTheme = selectedTheme
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "Dial Aesthetic Theme",
                        color = AuraTextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ClockDialTheme.values().forEach { theme ->
                            FilterChip(
                                selected = selectedTheme == theme,
                                onClick = {
                                    selectedTheme = theme
                                    repo.setClockDialTheme(theme)
                                    LuxuryClockWidgetProvider.updateAll(context)
                                },
                                label = { Text(theme.title, fontSize = 12.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = AuraGold,
                                    selectedLabelColor = Color(0xFF0F172A),
                                    containerColor = Color(0x221E293B),
                                    labelColor = AuraTextSecondary
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    borderColor = AuraGlassBorder,
                                    selectedBorderColor = AuraGold,
                                    enabled = true,
                                    selected = selectedTheme == theme
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = { openSystemClock(context) },
                            border = BorderStroke(1.dp, AuraGlassBorder),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Alarm, contentDescription = null, tint = AuraCyan, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Open Native Alarm Clock", color = AuraTextPrimary, fontSize = 12.sp)
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Tap target: ", color = AuraTextSecondary, fontSize = 12.sp)
                            FilterChip(
                                selected = tapTarget == "system",
                                onClick = {
                                    val newTarget = if (tapTarget == "system") "aura" else "system"
                                    tapTarget = newTarget
                                    repo.setWidgetTapTarget("clock", newTarget)
                                    LuxuryClockWidgetProvider.updateAll(context)
                                },
                                label = { Text(if (tapTarget == "system") "System App" else "AURA Studio", fontSize = 11.sp) }
                            )
                        }
                    }
                }
            }
        }
    }
}

// -----------------------------------------------------------------
// 5. PHOTO FRAME CUSTOMIZER SCREEN (2×2 Preferred)
// -----------------------------------------------------------------
@Composable
fun PhotoFrameCustomizerScreen(
    repo: AuraRepository,
    onPinWidget: () -> Unit
) {
    var photoIndex by remember { mutableStateOf(repo.getCurrentPhotoIndex()) }
    var isCustom by remember { mutableStateOf(repo.isUsingCustomPhoto()) }
    val context = LocalContext.current

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            val ok = repo.saveCustomPhoto(uri)
            if (ok) {
                isCustom = true
                PhotoFrameWidgetProvider.updateAll(context)
                Toast.makeText(context, "Custom photo imported to Living Photo Frame!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = AuraSurfaceCard),
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.dp, AuraGlassBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Living Photo Frame (2×2)",
                                color = AuraTextPrimary,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Prominent photo, fine glass rim, tiny date caption, tap slideshow.",
                                color = AuraTextSecondary,
                                fontSize = 12.sp
                            )
                        }
                        Button(
                            onClick = onPinWidget,
                            colors = ButtonDefaults.buttonColors(containerColor = AuraGold),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, tint = Color(0xFF0F172A), modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Pin Widget", color = Color(0xFF0F172A), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        AuraPhotoFrameWidget(
                            modifier = Modifier.size(180.dp),
                            repo = repo,
                            onTapNext = {
                                if (isCustom) {
                                    isCustom = false
                                    repo.toggleUseCustomPhoto(false)
                                } else {
                                    repo.advancePhoto()
                                    photoIndex = repo.getCurrentPhotoIndex()
                                }
                                PhotoFrameWidgetProvider.updateAll(context)
                            }
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        OutlinedButton(
                            onClick = {
                                isCustom = false
                                repo.toggleUseCustomPhoto(false)
                                repo.advancePhoto()
                                photoIndex = repo.getCurrentPhotoIndex()
                                PhotoFrameWidgetProvider.updateAll(context)
                            },
                            border = BorderStroke(1.dp, AuraGlassBorder),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.SkipNext, contentDescription = null, tint = AuraCyan, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Next Curated Photo", color = AuraTextPrimary, fontSize = 12.sp)
                        }

                        Button(
                            onClick = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = AuraSurfaceDark),
                            border = BorderStroke(1.dp, AuraCyan),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.PhotoLibrary, contentDescription = null, tint = AuraCyan, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Import Gallery Photo", color = AuraCyan, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

// -----------------------------------------------------------------
// 6. WORLD CLOCK CUSTOMIZER SCREEN (3×2 Preferred)
// -----------------------------------------------------------------
@Composable
fun WorldClockCustomizerScreen(
    repo: AuraRepository,
    onPinWidget: () -> Unit
) {
    val results = remember { repo.getCityTimeResults() }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = AuraSurfaceCard),
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.dp, AuraGlassBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "World Clock (3×2)",
                                color = AuraTextPrimary,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Four default cities: India, London, New York, Singapore.",
                                color = AuraTextSecondary,
                                fontSize = 12.sp
                            )
                        }
                        Button(
                            onClick = onPinWidget,
                            colors = ButtonDefaults.buttonColors(containerColor = AuraGold),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, tint = Color(0xFF0F172A), modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Pin Widget", color = Color(0xFF0F172A), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    AuraWorldClockWidget(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(160.dp),
                        repo = repo
                    )
                }
            }
        }

        item {
            Text(
                text = "ACTIVE WORLD TIME ZONES",
                color = AuraGold,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
        }

        items(results) { city ->
            Card(
                colors = CardDefaults.cardColors(containerColor = AuraSurfaceCard),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, AuraGlassBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = city.cityName,
                                color = AuraTextPrimary,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                            if (city.dayOffsetStr != null) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(Color(0x3338BDF8))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = city.dayOffsetStr,
                                        color = AuraCyan,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                        Text(
                            text = if (city.isDaytime) "Daytime • ${city.timeZoneAbbr}" else "Nighttime • ${city.timeZoneAbbr}",
                            color = AuraTextSecondary,
                            fontSize = 12.sp
                        )
                    }

                    Text(
                        text = city.formattedTime,
                        color = AuraTextPrimary,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

// -----------------------------------------------------------------
// 7. WEATHER CUSTOMIZER SCREEN (3×2 Preferred)
// -----------------------------------------------------------------
@Composable
fun WeatherCustomizerScreen(
    repo: AuraRepository,
    onPinWidget: () -> Unit
) {
    var weather by remember { mutableStateOf(repo.getWeatherData()) }
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var isLiveFetching by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = AuraSurfaceCard),
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.dp, AuraGlassBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Weather (3×2 Horizontal Split)",
                                color = AuraTextPrimary,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Current conditions on left, 3-day forecast on right.",
                                color = AuraTextSecondary,
                                fontSize = 12.sp
                            )
                        }
                        Button(
                            onClick = onPinWidget,
                            colors = ButtonDefaults.buttonColors(containerColor = AuraGold),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, tint = Color(0xFF0F172A), modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Pin Widget", color = Color(0xFF0F172A), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    AuraWeatherWidget(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(150.dp),
                        repo = repo
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = {
                                isLiveFetching = true
                                coroutineScope.launch {
                                    val ok = repo.refreshLiveWeather()
                                    weather = repo.getWeatherData()
                                    WeatherWidgetProvider.updateAll(context)
                                    isLiveFetching = false
                                    Toast.makeText(context, if (ok) "Live Open-Meteo weather synced!" else "Using cached forecast", Toast.LENGTH_SHORT).show()
                                }
                            },
                            enabled = !isLiveFetching,
                            colors = ButtonDefaults.buttonColors(containerColor = AuraGold),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            if (isLiveFetching) {
                                CircularProgressIndicator(color = Color(0xFF0F172A), modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Syncing...", color = Color(0xFF0F172A), fontSize = 12.sp)
                            } else {
                                Icon(Icons.Default.CloudSync, contentDescription = null, tint = Color(0xFF0F172A), modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Fetch Live Weather", color = Color(0xFF0F172A), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }

                        // Simulation condition chips
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf("Clear", "Rain", "Cloudy").forEach { cond ->
                                FilterChip(
                                    selected = weather.condition.contains(cond, ignoreCase = true),
                                    onClick = {
                                        val newCond = if (cond == "Clear") "Sunny" else if (cond == "Rain") "Rainy" else "Partly Cloudy"
                                        repo.updateWeatherSettings(weather.cityName, weather.currentTempC, newCond)
                                        weather = repo.getWeatherData()
                                        WeatherWidgetProvider.updateAll(context)
                                    },
                                    label = { Text(cond, fontSize = 11.sp) }
                                )
                            }
                        }
                    }
                }
            }
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = AuraSurfaceCard),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, AuraGlassBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Clean Weather Sizing Principles",
                        color = AuraCyan,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("✓ Current temperature & short condition string", color = AuraTextPrimary, fontSize = 12.sp)
                    Text("✓ Today's High and Low concise display", color = AuraTextPrimary, fontSize = 12.sp)
                    Text("✓ 3-day compact forecast with day, icon, H/L, and rain %", color = AuraTextPrimary, fontSize = 12.sp)
                    Text("✓ NO large decorative charts or oversized cards", color = AuraTextPrimary, fontSize = 12.sp)
                }
            }
        }
    }
}

// -----------------------------------------------------------------
// Official Android Widget Pinning Action (Launcher Add)
// -----------------------------------------------------------------
fun pinWidget(context: Context, providerClass: Class<*>) {
    val appWidgetManager = AppWidgetManager.getInstance(context)
    val providerComponent = ComponentName(context, providerClass)

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        if (appWidgetManager.isRequestPinAppWidgetSupported) {
            val successIntent = Intent(context, providerClass).apply {
                action = AppWidgetManager.ACTION_APPWIDGET_UPDATE
            }
            val successCallback = PendingIntent.getBroadcast(
                context,
                0,
                successIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            appWidgetManager.requestPinAppWidget(providerComponent, null, successCallback)
            Toast.makeText(context, "Adding widget to Home Screen...", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "Launcher does not support direct pin. Add from home screen widget menu.", Toast.LENGTH_LONG).show()
        }
    } else {
        Toast.makeText(context, "Long press home screen to add AURA widget.", Toast.LENGTH_LONG).show()
    }
}

fun openSystemCalendar(context: Context) {
    try {
        val intent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_APP_CALENDAR)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    } catch (e: Exception) {
        try {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                data = android.net.Uri.parse("content://com.android.calendar/time")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (e2: Exception) {
            Toast.makeText(context, "No system calendar application found", Toast.LENGTH_SHORT).show()
        }
    }
}

fun openSystemClock(context: Context) {
    try {
        val intent = Intent(AlarmClock.ACTION_SHOW_ALARMS).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    } catch (e: Exception) {
        try {
            val intent = Intent(Intent.ACTION_MAIN).apply {
                addCategory("android.intent.category.APP_CLOCK")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (e2: Exception) {
            Toast.makeText(context, "No system clock application found", Toast.LENGTH_SHORT).show()
        }
    }
}
