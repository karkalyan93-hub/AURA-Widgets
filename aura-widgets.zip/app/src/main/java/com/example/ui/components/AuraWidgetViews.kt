package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AuraRepository
import com.example.model.*
import com.example.ui.theme.*
import java.time.LocalDate
import java.time.LocalTime
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

// -------------------------------------------------------------
// 1. MONTHLY CALENDAR COMPOSABLE (Preferred Default: 4×3)
// -------------------------------------------------------------
@Composable
fun AuraCalendarWidget(
    modifier: Modifier = Modifier,
    repo: AuraRepository,
    targetDate: LocalDate = LocalDate.now(),
    cellSpan: String = "4×3"
) {
    val calData = remember(targetDate) { repo.getCalendarData(targetDate) }
    val isCompact = cellSpan == "3×3"

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(22.dp))
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0x381E293B),
                        Color(0x280F172A)
                    )
                )
            )
            .border(
                width = 1.dp,
                brush = Brush.linearGradient(
                    colors = listOf(Color(0x4DFFFFFF), Color(0x18FFFFFF))
                ),
                shape = RoundedCornerShape(22.dp)
            )
            .padding(horizontal = if (isCompact) 12.dp else 16.dp, vertical = if (isCompact) 10.dp else 14.dp)
            .testTag("widget_calendar_view")
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Month & Year in small elegant heading
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${calData.monthName.uppercase()}  ${calData.year}",
                    color = AuraTextPrimary,
                    fontSize = if (isCompact) 13.sp else 15.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.5.sp
                )
                Text(
                    text = cellSpan,
                    color = AuraTextMuted,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Monday-first 7-column header
            val weekdayHeaders = listOf("M", "T", "W", "T", "F", "S", "S")
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                weekdayHeaders.forEachIndexed { idx, label ->
                    Text(
                        text = label,
                        color = if (idx >= 5) AuraTextMuted else AuraTextSecondary,
                        fontSize = if (isCompact) 10.sp else 11.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Complete calendar grid supporting 5 or 6 rows cleanly
            val startCol = calData.startDayOfWeekMondayBased
            var currentDay = 1

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.SpaceEvenly
            ) {
                for (row in 0 until calData.totalRowsNeeded) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        for (col in 0 until 7) {
                            val cellIndex = row * 7 + col
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .aspectRatio(1.2f),
                                contentAlignment = Alignment.Center
                            ) {
                                if (cellIndex >= startCol && currentDay <= calData.daysInMonth) {
                                    val isToday = (currentDay == calData.todayDayOfMonth)
                                    if (isToday) {
                                        Box(
                                            modifier = Modifier
                                                .size(if (isCompact) 20.dp else 24.dp)
                                                .background(AuraGold, CircleShape),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = currentDay.toString(),
                                                color = Color(0xFF0F172A),
                                                fontSize = if (isCompact) 10.sp else 11.5.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    } else {
                                        Text(
                                            text = currentDay.toString(),
                                            color = if (col >= 5) AuraTextMuted else AuraTextPrimary,
                                            fontSize = if (isCompact) 11.sp else 12.5.sp,
                                            fontWeight = FontWeight.Normal
                                        )
                                    }
                                    currentDay++
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// 2. LUXURY ANALOGUE CLOCK COMPOSABLE (Preferred Default: 2×2)
// -------------------------------------------------------------
@Composable
fun AuraLuxuryClockWidget(
    modifier: Modifier = Modifier,
    repo: AuraRepository,
    dialTheme: ClockDialTheme = repo.getClockDialTheme()
) {
    // Dynamic ticking clock
    var currentTime by remember { mutableStateOf(LocalTime.now()) }
    LaunchedEffect(Unit) {
        while (true) {
            currentTime = LocalTime.now()
            kotlinx.coroutines.delay(1000)
        }
    }

    Box(
        modifier = modifier
            .aspectRatio(1f)
            .testTag("widget_luxury_clock_view"),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val cx = size.width / 2f
            val cy = size.height / 2f
            val radius = (size.minDimension / 2f) - 4.dp.toPx()

            // 1. Sapphire glass bevel outer ring
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0x33FFFFFF), Color(0x0CFFFFFF), Color(0x38000000)),
                    center = Offset(cx, cy),
                    radius = radius
                ),
                radius = radius,
                center = Offset(cx, cy)
            )

            // 2. Dial center disk
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xFF1E293B), Color(dialTheme.dialBg), Color(0xFF060A12)),
                    center = Offset(cx, cy),
                    radius = radius * 0.94f
                ),
                radius = radius * 0.94f,
                center = Offset(cx, cy)
            )

            // 3. Hairline dial border
            drawCircle(
                color = Color(0x44FFFFFF),
                radius = radius * 0.94f,
                center = Offset(cx, cy),
                style = Stroke(width = 1.dp.toPx())
            )

            // 4. Subtle sapphire light glare
            drawArc(
                brush = Brush.linearGradient(
                    colors = listOf(Color(0x2EFFFFFF), Color.Transparent),
                    start = Offset(cx - radius * 0.7f, cy - radius * 0.7f),
                    end = Offset(cx + radius * 0.3f, cy + radius * 0.3f)
                ),
                startAngle = 180f,
                sweepAngle = 110f,
                useCenter = true,
                topLeft = Offset(cx - radius * 0.88f, cy - radius * 0.88f),
                size = Size(radius * 1.76f, radius * 1.76f)
            )

            // 5. Hour batons (refined markings, NO date/weather/digital clock)
            for (i in 0 until 12) {
                val angleDeg = i * 30.0
                val angleRad = Math.toRadians(angleDeg)
                val isCardinal = (i % 3 == 0)

                val innerR = if (isCardinal) radius * 0.73f else radius * 0.82f
                val outerR = radius * 0.88f

                val x1 = (cx + innerR * sin(angleRad)).toFloat()
                val y1 = (cy - innerR * cos(angleRad)).toFloat()
                val x2 = (cx + outerR * sin(angleRad)).toFloat()
                val y2 = (cy - outerR * cos(angleRad)).toFloat()

                drawLine(
                    color = if (isCardinal) Color(0xFFF8FAFC) else Color(0xFFA0ABC0),
                    start = Offset(x1, y1),
                    end = Offset(x2, y2),
                    strokeWidth = if (isCardinal) 2.2.dp.toPx() else 1.2.dp.toPx(),
                    cap = StrokeCap.Round
                )
            }

            // 6. Hour and Minute hands
            val hour = currentTime.hour % 12
            val minute = currentTime.minute
            val second = currentTime.second

            val hourAngleRad = Math.toRadians((hour * 30.0) + (minute * 0.5))
            val minAngleRad = Math.toRadians((minute * 6.0) + (second * 0.1))

            // Hour Hand
            val hourLen = radius * 0.52f
            val hx = (cx + hourLen * sin(hourAngleRad)).toFloat()
            val hy = (cy - hourLen * cos(hourAngleRad)).toFloat()
            drawLine(
                color = Color(dialTheme.handColor),
                start = Offset(cx, cy),
                end = Offset(hx, hy),
                strokeWidth = 2.6.dp.toPx(),
                cap = StrokeCap.Round
            )

            // Minute Hand
            val minLen = radius * 0.74f
            val mx = (cx + minLen * sin(minAngleRad)).toFloat()
            val my = (cy - minLen * cos(minAngleRad)).toFloat()
            drawLine(
                color = Color(dialTheme.accentColor),
                start = Offset(cx, cy),
                end = Offset(mx, my),
                strokeWidth = 1.8.dp.toPx(),
                cap = StrokeCap.Round
            )

            // Center Jewel Pin
            drawCircle(
                color = Color.White,
                radius = 3.5.dp.toPx(),
                center = Offset(cx, cy)
            )
            drawCircle(
                color = Color(dialTheme.handColor),
                radius = 1.8.dp.toPx(),
                center = Offset(cx, cy)
            )
        }
    }
}

// -------------------------------------------------------------
// 3. LIVING PHOTO FRAME COMPOSABLE (Preferred Default: 2×2)
// -------------------------------------------------------------
@Composable
fun AuraPhotoFrameWidget(
    modifier: Modifier = Modifier,
    repo: AuraRepository,
    onTapNext: () -> Unit = {}
) {
    val photoIndex = repo.getCurrentPhotoIndex()
    val photo = repo.curatedPhotos[photoIndex]
    val isCustom = repo.isUsingCustomPhoto()
    val customBmp = remember(isCustom) { if (isCustom) repo.getCustomPhotoBitmap() else null }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .border(
                width = 1.2.dp,
                brush = Brush.linearGradient(
                    colors = listOf(Color(0x4DFFFFFF), Color(0x18FFFFFF))
                ),
                shape = RoundedCornerShape(20.dp)
            )
            .clickable { onTapNext() }
            .testTag("widget_photo_frame_view")
    ) {
        if (isCustom && customBmp != null) {
            androidx.compose.foundation.Image(
                bitmap = customBmp.asImageBitmap(),
                contentDescription = "Living Photo Frame",
                contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height

                // Render artistic photography
                when (photo.id) {
                    "arch_1" -> {
                        drawRect(
                            brush = Brush.linearGradient(
                                listOf(Color(0xFF1E293B), Color(0xFF0F172A))
                            )
                        )
                        drawRect(
                            brush = Brush.radialGradient(
                                colors = listOf(Color(0xE6F59E0B), Color.Transparent),
                                center = Offset(w * 0.75f, h * 0.25f),
                                radius = w * 0.7f
                            )
                        )
                        drawRect(
                            color = Color(0xFF090D16),
                            topLeft = Offset(w * 0.15f, h * 0.45f),
                            size = Size(w * 0.7f, h * 0.55f)
                        )
                    }
                    "nature_1" -> {
                        drawRect(
                            brush = Brush.verticalGradient(
                                listOf(Color(0xFF061A14), Color(0xFF0B2B22))
                            )
                        )
                        drawRect(
                            brush = Brush.verticalGradient(
                                colors = listOf(Color.Transparent, Color(0x4D38BDF8), Color.Transparent),
                                startY = h * 0.3f,
                                endY = h * 0.7f
                            )
                        )
                    }
                    else -> {
                        drawRect(
                            brush = Brush.linearGradient(
                                listOf(Color(0xFF0F172A), Color(0xFF020617))
                            )
                        )
                        drawCircle(
                            brush = Brush.radialGradient(
                                listOf(Color(0x4D38BDF8), Color.Transparent),
                                center = Offset(w * 0.3f, h * 0.3f),
                                radius = w * 0.6f
                            ),
                            radius = w * 0.6f,
                            center = Offset(w * 0.3f, h * 0.3f)
                        )
                    }
                }
            }
        }

        // Tiny date caption in the corner (minimal, non-cluttered)
        val captionText = if (isCustom) "PHOTO" else photo.dateCaption
        if (captionText.isNotEmpty()) {
            Text(
                text = captionText,
                color = Color(0xE0FFFFFF),
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(10.dp)
            )
        }
    }
}

// -------------------------------------------------------------
// 4. WORLD CLOCK COMPOSABLE (Preferred Default: 3×2)
// -------------------------------------------------------------
@Composable
fun AuraWorldClockWidget(
    modifier: Modifier = Modifier,
    repo: AuraRepository,
    cellSpan: String = "3×2"
) {
    var cityResults by remember { mutableStateOf(repo.getCityTimeResults()) }
    LaunchedEffect(Unit) {
        while (true) {
            cityResults = repo.getCityTimeResults()
            kotlinx.coroutines.delay(10000)
        }
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(22.dp))
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(Color(0x381E293B), Color(0x280F172A))
                )
            )
            .border(
                width = 1.dp,
                brush = Brush.linearGradient(
                    colors = listOf(Color(0x4DFFFFFF), Color(0x18FFFFFF))
                ),
                shape = RoundedCornerShape(22.dp)
            )
            .padding(12.dp)
            .testTag("widget_world_clock_view")
    ) {
        // Standard 3x2: 2x2 grid
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceEvenly
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                CityCard(cityResults[0], modifier = Modifier.weight(1f))
                Spacer(modifier = Modifier.width(8.dp))
                CityCard(cityResults[1], modifier = Modifier.weight(1f))
            }
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                CityCard(cityResults[2], modifier = Modifier.weight(1f))
                Spacer(modifier = Modifier.width(8.dp))
                CityCard(cityResults[3], modifier = Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun CityCard(city: AuraRepository.CityTimeResult, modifier: Modifier = Modifier) {
    Column(modifier = modifier) {
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = city.cityName.uppercase(),
                color = AuraTextSecondary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )
            if (city.dayOffsetStr != null) {
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = city.dayOffsetStr,
                    color = AuraCyan,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = city.formattedTime,
                color = AuraTextPrimary,
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.width(6.dp))
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .background(
                        color = if (city.isDaytime) AuraGold else AuraCyan,
                        shape = CircleShape
                    )
            )
        }
    }
}

// -------------------------------------------------------------
// 5. WEATHER WIDGET COMPOSABLE (Preferred Default: 3×2)
// -------------------------------------------------------------
@Composable
fun AuraWeatherWidget(
    modifier: Modifier = Modifier,
    repo: AuraRepository
) {
    val weather = remember { repo.getWeatherData() }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(22.dp))
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(Color(0x381E293B), Color(0x280F172A))
                )
            )
            .border(
                width = 1.dp,
                brush = Brush.linearGradient(
                    colors = listOf(Color(0x4DFFFFFF), Color(0x18FFFFFF))
                ),
                shape = RoundedCornerShape(22.dp)
            )
            .padding(14.dp)
            .testTag("widget_weather_view")
    ) {
        Row(
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Left Section: Current Temperature, Icon, Condition, H/L
            Column(
                modifier = Modifier
                    .weight(0.9f)
                    .fillMaxHeight(),
                verticalArrangement = Arrangement.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "${weather.currentTempC}°",
                        color = AuraTextPrimary,
                        fontSize = 30.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(AuraGold, CircleShape)
                    )
                }
                Text(
                    text = weather.condition,
                    color = AuraTextPrimary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "H: ${weather.highTempC}°  L: ${weather.lowTempC}°",
                    color = AuraTextMuted,
                    fontSize = 10.sp
                )
            }

            // Divider
            Box(
                modifier = Modifier
                    .width(1.dp)
                    .fillMaxHeight(0.7f)
                    .background(Color(0x1FFFFFFF))
            )

            // Right Section: 3-Day Forecast
            Row(
                modifier = Modifier
                    .weight(1.1f)
                    .fillMaxHeight(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                weather.forecast.take(3).forEach { f ->
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = f.dayName,
                            color = AuraTextSecondary,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .background(
                                    color = if (f.iconType == WeatherIconType.RAINY) AuraCyan else AuraGold,
                                    shape = CircleShape
                                )
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "${f.highTempC}°/${f.lowTempC}°",
                            color = AuraTextPrimary,
                            fontSize = 9.5.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "${f.rainProb}%",
                            color = AuraCyan,
                            fontSize = 8.5.sp
                        )
                    }
                }
            }
        }
    }
}
