package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val AuraObsidian = Color(0xFF090D16)
val AuraSurfaceDark = Color(0xFF0F172A)
val AuraSurfaceCard = Color(0xFF1E293B)
val AuraGlassFill = Color(0x28FFFFFF)
val AuraGlassBorder = Color(0x38FFFFFF)

val AuraGold = Color(0xFFF59E0B)
val AuraGoldBright = Color(0xFFFCD34D)
val AuraCyan = Color(0xFF38BDF8)
val AuraCyanGlow = Color(0xFF0284C7)
val AuraEmerald = Color(0xFF10B981)

val AuraTextPrimary = Color(0xFFF8FAFC)
val AuraTextSecondary = Color(0xFF94A3B8)
val AuraTextMuted = Color(0xFF64748B)

// Material Theme standard mappings
val AuraPrimary = AuraGold
val AuraOnPrimary = Color(0xFF1E1B16)
val AuraSecondary = AuraCyan
val AuraOnSecondary = Color(0xFF082F49)
val AuraBackground = AuraObsidian
val AuraSurface = AuraSurfaceDark
