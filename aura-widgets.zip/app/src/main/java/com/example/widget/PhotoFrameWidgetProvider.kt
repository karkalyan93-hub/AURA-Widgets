package com.example.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.RemoteViews
import com.example.MainActivity
import com.example.R
import com.example.data.AuraRepository

class PhotoFrameWidgetProvider : AppWidgetProvider() {

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val action = intent.action
        if (action == "com.example.ACTION_NEXT_PHOTO") {
            val repo = AuraRepository.getInstance(context)
            repo.advancePhoto()
            updateAll(context)
        } else if (action == "com.example.ACTION_UPDATE_PHOTOS") {
            updateAll(context)
        }
    }

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        val repo = AuraRepository.getInstance(context)
        for (appWidgetId in appWidgetIds) {
            val options = appWidgetManager.getAppWidgetOptions(appWidgetId)
            updateWidget(context, appWidgetManager, appWidgetId, options, repo)
        }
    }

    override fun onAppWidgetOptionsChanged(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetId: Int,
        newOptions: Bundle
    ) {
        val repo = AuraRepository.getInstance(context)
        updateWidget(context, appWidgetManager, appWidgetId, newOptions, repo)
    }

    companion object {
        fun updateAll(context: Context) {
            val appWidgetManager = AppWidgetManager.getInstance(context)
            val ids = appWidgetManager.getAppWidgetIds(
                ComponentName(context, PhotoFrameWidgetProvider::class.java)
            )
            val repo = AuraRepository.getInstance(context)
            for (id in ids) {
                val options = appWidgetManager.getAppWidgetOptions(id)
                updateWidget(context, appWidgetManager, id, options, repo)
            }
        }

        fun updateWidget(
            context: Context,
            appWidgetManager: AppWidgetManager,
            appWidgetId: Int,
            options: Bundle?,
            repo: AuraRepository
        ) {
            // Preferred 2x2 cells: minWidth 110dp, minHeight 110dp
            val minWidthDp = options?.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH) ?: 110
            val minHeightDp = options?.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT) ?: 110

            val widthPx = WidgetRenderer.dpToPx(context, minWidthDp.toFloat().coerceAtLeast(90f)).toInt()
            val heightPx = WidgetRenderer.dpToPx(context, minHeightDp.toFloat().coerceAtLeast(90f)).toInt()

            val bitmap = WidgetRenderer.renderPhotoFrameBitmap(context, widthPx, heightPx, repo)

            val views = RemoteViews(context.packageName, R.layout.widget_photo_frame_layout)
            views.setImageViewBitmap(R.id.widget_photo_frame_image, bitmap)

            // Tap action: cycles slideshow directly on the widget
            val nextIntent = Intent(context, PhotoFrameWidgetProvider::class.java).apply {
                action = "com.example.ACTION_NEXT_PHOTO"
            }
            val pendingIntent = PendingIntent.getBroadcast(
                context,
                appWidgetId,
                nextIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_photo_frame_root, pendingIntent)

            appWidgetManager.updateAppWidget(appWidgetId, views)
        }
    }
}
