package com.example.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.RemoteViews
import com.example.MainActivity
import com.example.R
import com.example.data.AuraRepository

class CalendarWidgetProvider : AppWidgetProvider() {

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val action = intent.action
        if (action == Intent.ACTION_DATE_CHANGED ||
            action == Intent.ACTION_TIME_CHANGED ||
            action == Intent.ACTION_TIMEZONE_CHANGED ||
            action == "com.example.ACTION_UPDATE_CALENDAR"
        ) {
            updateAll(context)
        }
    }

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        val repo = AuraRepository.getInstance(context)
        for (appWidgetId in appWidgetIds) {
            val options = appWidgetManager.getAppWidgetOptions(appWidgetId)
            updateWidget(context, appWidgetManager, appWidgetId, options, repo)
        }
    }

    override fun onAppWidgetOptionsChanged(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetId: Int,
        newOptions: Bundle
    ) {
        val repo = AuraRepository.getInstance(context)
        updateWidget(context, appWidgetManager, appWidgetId, newOptions, repo)
    }

    companion object {
        fun updateAll(context: Context) {
            val appWidgetManager = AppWidgetManager.getInstance(context)
            val ids = appWidgetManager.getAppWidgetIds(
                ComponentName(context, CalendarWidgetProvider::class.java)
            )
            val repo = AuraRepository.getInstance(context)
            for (id in ids) {
                val options = appWidgetManager.getAppWidgetOptions(id)
                updateWidget(context, appWidgetManager, id, options, repo)
            }
        }

        fun updateWidget(
            context: Context,
            appWidgetManager: AppWidgetManager,
            appWidgetId: Int,
            options: Bundle?,
            repo: AuraRepository
        ) {
            // Preferred 4x3 cells: minWidth 250dp, minHeight 180dp
            val minWidthDp = options?.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH) ?: 250
            val minHeightDp = options?.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT) ?: 180

            val widthPx = WidgetRenderer.dpToPx(context, minWidthDp.toFloat().coerceAtLeast(180f)).toInt()
            val heightPx = WidgetRenderer.dpToPx(context, minHeightDp.toFloat().coerceAtLeast(120f)).toInt()

            val bitmap = WidgetRenderer.renderCalendarBitmap(context, widthPx, heightPx, repo)

            val views = RemoteViews(context.packageName, R.layout.widget_calendar_layout)
            views.setImageViewBitmap(R.id.widget_calendar_image, bitmap)

            // Tap action: Opens AURA Calendar Studio or native system Calendar
            val tapTarget = repo.getWidgetTapTarget("calendar")
            val intent = if (tapTarget == "system") {
                Intent(Intent.ACTION_MAIN).apply {
                    addCategory(Intent.CATEGORY_APP_CALENDAR)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
            } else {
                Intent(context, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                    putExtra("selected_widget_tab", "calendar")
                }
            }

            val pendingIntent = PendingIntent.getActivity(
                context,
                101,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_calendar_root, pendingIntent)

            appWidgetManager.updateAppWidget(appWidgetId, views)
        }
    }
}
