package com.example.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.RemoteViews
import com.example.MainActivity
import com.example.R
import com.example.data.AuraRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class WeatherWidgetProvider : AppWidgetProvider() {

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val action = intent.action
        if (action == "com.example.ACTION_REFRESH_WEATHER") {
            val repo = AuraRepository.getInstance(context)
            val pendingResult = goAsync()
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    repo.refreshLiveWeather()
                } finally {
                    updateAll(context)
                    pendingResult.finish()
                }
            }
        } else if (action == "com.example.ACTION_UPDATE_WEATHER") {
            updateAll(context)
        }
    }

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        val repo = AuraRepository.getInstance(context)
        for (appWidgetId in appWidgetIds) {
            val options = appWidgetManager.getAppWidgetOptions(appWidgetId)
            updateWidget(context, appWidgetManager, appWidgetId, options, repo)
        }
    }

    override fun onAppWidgetOptionsChanged(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetId: Int,
        newOptions: Bundle
    ) {
        val repo = AuraRepository.getInstance(context)
        updateWidget(context, appWidgetManager, appWidgetId, newOptions, repo)
    }

    companion object {
        fun updateAll(context: Context) {
            val appWidgetManager = AppWidgetManager.getInstance(context)
            val ids = appWidgetManager.getAppWidgetIds(
                ComponentName(context, WeatherWidgetProvider::class.java)
            )
            val repo = AuraRepository.getInstance(context)
            for (id in ids) {
                val options = appWidgetManager.getAppWidgetOptions(id)
                updateWidget(context, appWidgetManager, id, options, repo)
            }
        }

        fun updateWidget(
            context: Context,
            appWidgetManager: AppWidgetManager,
            appWidgetId: Int,
            options: Bundle?,
            repo: AuraRepository
        ) {
            // Preferred 3x2 cells: minWidth 180dp, minHeight 110dp
            val minWidthDp = options?.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH) ?: 180
            val minHeightDp = options?.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT) ?: 110

            val widthPx = WidgetRenderer.dpToPx(context, minWidthDp.toFloat().coerceAtLeast(140f)).toInt()
            val heightPx = WidgetRenderer.dpToPx(context, minHeightDp.toFloat().coerceAtLeast(90f)).toInt()

            val bitmap = WidgetRenderer.renderWeatherBitmap(context, widthPx, heightPx, repo)

            val views = RemoteViews(context.packageName, R.layout.widget_weather_layout)
            views.setImageViewBitmap(R.id.widget_weather_image, bitmap)

            // Tap action opens Weather Studio in app
            val intent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra("selected_widget_tab", "weather")
            }
            val pendingIntent = PendingIntent.getActivity(
                context,
                104,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_weather_root, pendingIntent)

            appWidgetManager.updateAppWidget(appWidgetId, views)
        }
    }
}
