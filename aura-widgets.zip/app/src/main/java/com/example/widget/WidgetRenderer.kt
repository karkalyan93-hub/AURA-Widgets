package com.example.widget

import android.content.Context
import android.graphics.*
import com.example.data.AuraRepository
import com.example.model.ClockDialTheme
import com.example.model.WeatherIconType
import java.time.LocalTime
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

object WidgetRenderer {

    // Converts dp to px based on display metrics
    fun dpToPx(context: Context, dp: Float): Float {
        return dp * context.resources.displayMetrics.density
    }

    // -------------------------------------------------------------
    // 1. MONTHLY CALENDAR (Preferred Default: 4×3 cells)
    // -------------------------------------------------------------
    fun renderCalendarBitmap(
        context: Context,
        widthPx: Int,
        heightPx: Int,
        repo: AuraRepository
    ): Bitmap {
        val w = widthPx.coerceAtLeast(300)
        val h = heightPx.coerceAtLeast(200)
        val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        val calData = repo.getCalendarData()

        // 1. Frosted Glass Background
        drawGlassBackground(canvas, w.toFloat(), h.toFloat(), cornerRadius = dpToPx(context, 22f))

        // Text & Grid Setup
        val paddingHorizontal = dpToPx(context, 16f)
        val paddingTop = dpToPx(context, 14f)
        val paddingBottom = dpToPx(context, 12f)

        // Title Paint (Month & Year in small elegant heading)
        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#F8FAFC")
            textSize = dpToPx(context, if (h < 350) 13f else 15f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            letterSpacing = 0.08f
        }

        val titleText = "${calData.monthName.uppercase()}  ${calData.year}"
        canvas.drawText(titleText, paddingHorizontal, paddingTop + titlePaint.textSize, titlePaint)

        // Monday-first weekday headers
        val weekdayHeaders = listOf("M", "T", "W", "T", "F", "S", "S")
        val headerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#64748B")
            textSize = dpToPx(context, if (h < 350) 10f else 11f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }

        val gridTop = paddingTop + titlePaint.textSize + dpToPx(context, 14f)
        val availableGridHeight = h - gridTop - paddingBottom
        val availableGridWidth = w - (paddingHorizontal * 2)

        val colWidth = availableGridWidth / 7f
        val numRows = calData.totalRowsNeeded // 5 or 6 rows for full month visibility
        val rowHeight = availableGridHeight / (numRows + 1f) // +1 for day-of-week header row

        // Draw weekday labels
        val headerY = gridTop + rowHeight * 0.7f
        for (i in 0 until 7) {
            val cx = paddingHorizontal + (i + 0.5f) * colWidth
            canvas.drawText(weekdayHeaders[i], cx, headerY, headerPaint)
        }

        // Draw date numbers
        val datePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#E2E8F0")
            textSize = dpToPx(context, if (h < 350) 11.5f else 13f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            textAlign = Paint.Align.CENTER
        }

        val todayBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#E0F59E0B") // Subtle gold accent pill
            style = Paint.Style.FILL
        }

        val todayTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#0F172A") // Dark text inside gold highlight
            textSize = datePaint.textSize
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }

        val startCol = calData.startDayOfWeekMondayBased // 0..6
        var currentDay = 1

        for (row in 0 until numRows) {
            val cellY = gridTop + (row + 1) * rowHeight + rowHeight * 0.7f
            val centerY = gridTop + (row + 1) * rowHeight + rowHeight * 0.45f

            for (col in 0 until 7) {
                val cellIndex = row * 7 + col
                if (cellIndex >= startCol && currentDay <= calData.daysInMonth) {
                    val cx = paddingHorizontal + (col + 0.5f) * colWidth
                    val isToday = (currentDay == calData.todayDayOfMonth)

                    if (isToday) {
                        val pillRadius = min(colWidth * 0.42f, rowHeight * 0.42f)
                        canvas.drawCircle(cx, centerY, pillRadius, todayBgPaint)
                        canvas.drawText(currentDay.toString(), cx, cellY, todayTextPaint)
                    } else {
                        // Muted weekend color or normal weekday
                        datePaint.color = if (col >= 5) Color.parseColor("#94A3B8") else Color.parseColor("#E2E8F0")
                        canvas.drawText(currentDay.toString(), cx, cellY, datePaint)
                    }
                    currentDay++
                }
            }
        }

        return bitmap
    }

    // -------------------------------------------------------------
    // 2. LUXURY ANALOGUE CLOCK (Preferred Default: 2×2 cells)
    // -------------------------------------------------------------
    fun renderLuxuryClockBitmap(
        context: Context,
        widthPx: Int,
        heightPx: Int,
        repo: AuraRepository
    ): Bitmap {
        val size = min(widthPx, heightPx).coerceAtLeast(200)
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        val cx = size / 2f
        val cy = size / 2f
        val radius = (size / 2f) - dpToPx(context, 6f)

        val theme = repo.getClockDialTheme()

        // 1. Subtle Outer Dial Ring (Sapphire glass bevel)
        val outerRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = RadialGradient(
                cx, cy, radius,
                intArrayOf(Color.parseColor("#22FFFFFF"), Color.parseColor("#08FFFFFF"), Color.parseColor("#33000000")),
                floatArrayOf(0.7f, 0.92f, 1.0f),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawCircle(cx, cy, radius, outerRingPaint)

        // 2. Watch Face Background (Center watch disc)
        val dialPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = RadialGradient(
                cx, cy, radius * 0.96f,
                intArrayOf(Color.parseColor("#1E293B"), theme.dialBg, Color.parseColor("#060A12")),
                floatArrayOf(0.0f, 0.75f, 1.0f),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawCircle(cx, cy, radius * 0.94f, dialPaint)

        // 3. Hairline Dial Bezel Border
        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#44FFFFFF")
            style = Paint.Style.STROKE
            strokeWidth = dpToPx(context, 1f)
        }
        canvas.drawCircle(cx, cy, radius * 0.94f, borderPaint)

        // 4. Subtle Sapphire Reflection Arc (Top-left glass glare)
        val glarePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(
                cx - radius * 0.7f, cy - radius * 0.7f,
                cx + radius * 0.3f, cy + radius * 0.3f,
                Color.parseColor("#30FFFFFF"),
                Color.TRANSPARENT,
                Shader.TileMode.CLAMP
            )
        }
        val glareRect = RectF(cx - radius * 0.88f, cy - radius * 0.88f, cx + radius * 0.88f, cy + radius * 0.88f)
        canvas.drawArc(glareRect, 180f, 110f, true, glarePaint)

        // 5. Hour Markers (Thin refined batons)
        val batonPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#F8FAFC")
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
        }

        val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#94A3B8")
            style = Paint.Style.FILL
        }

        for (i in 0 until 12) {
            val angleDeg = i * 30.0
            val angleRad = Math.toRadians(angleDeg)
            val isCardinal = (i % 3 == 0)

            val innerR = if (isCardinal) radius * 0.74f else radius * 0.82f
            val outerR = radius * 0.88f

            val x1 = (cx + innerR * sin(angleRad)).toFloat()
            val y1 = (cy - innerR * cos(angleRad)).toFloat()
            val x2 = (cx + outerR * sin(angleRad)).toFloat()
            val y2 = (cy - outerR * cos(angleRad)).toFloat()

            if (isCardinal) {
                batonPaint.strokeWidth = dpToPx(context, 2f)
                batonPaint.color = Color.parseColor("#F8FAFC")
                canvas.drawLine(x1, y1, x2, y2, batonPaint)
            } else {
                batonPaint.strokeWidth = dpToPx(context, 1f)
                batonPaint.color = Color.parseColor("#A0ABC0")
                canvas.drawLine(x1, y1, x2, y2, batonPaint)
            }
        }

        // 6. Clock Hands (Current Time)
        val now = LocalTime.now()
        val hour = now.hour % 12
        val minute = now.minute
        val second = now.second

        val hourAngleRad = Math.toRadians((hour * 30.0) + (minute * 0.5))
        val minuteAngleRad = Math.toRadians((minute * 6.0) + (second * 0.1))

        // Hour Hand (Refined baton with gold/accent tone)
        val hourHandPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = theme.handColor
            strokeWidth = dpToPx(context, 2.5f)
            strokeCap = Paint.Cap.ROUND
            setShadowLayer(dpToPx(context, 2f), 0f, dpToPx(context, 1f), Color.parseColor("#80000000"))
        }
        val hourLen = radius * 0.52f
        val hx = (cx + hourLen * sin(hourAngleRad)).toFloat()
        val hy = (cy - hourLen * cos(hourAngleRad)).toFloat()
        canvas.drawLine(cx, cy, hx, hy, hourHandPaint)

        // Minute Hand (Slightly longer and thinner)
        val minHandPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = theme.accentColor
            strokeWidth = dpToPx(context, 1.8f)
            strokeCap = Paint.Cap.ROUND
            setShadowLayer(dpToPx(context, 2f), 0f, dpToPx(context, 1f), Color.parseColor("#80000000"))
        }
        val minLen = radius * 0.74f
        val mx = (cx + minLen * sin(minuteAngleRad)).toFloat()
        val my = (cy - minLen * cos(minuteAngleRad)).toFloat()
        canvas.drawLine(cx, cy, mx, my, minHandPaint)

        // Center Cap (Jewel Pin)
        val centerPinOuter = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#FFFFFF")
            style = Paint.Style.FILL
        }
        canvas.drawCircle(cx, cy, dpToPx(context, 3.5f), centerPinOuter)

        val centerPinInner = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = theme.handColor
            style = Paint.Style.FILL
        }
        canvas.drawCircle(cx, cy, dpToPx(context, 1.8f), centerPinInner)

        return bitmap
    }

    // -------------------------------------------------------------
    // 3. LIVING PHOTO FRAME (Preferred Default: 2×2 cells)
    // -------------------------------------------------------------
    fun renderPhotoFrameBitmap(
        context: Context,
        widthPx: Int,
        heightPx: Int,
        repo: AuraRepository
    ): Bitmap {
        val w = widthPx.coerceAtLeast(200)
        val h = heightPx.coerceAtLeast(200)
        val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        val customBmp = if (repo.isUsingCustomPhoto()) repo.getCustomPhotoBitmap() else null
        val cornerR = dpToPx(context, 20f)

        if (customBmp != null) {
            val clipPath = Path().apply {
                addRoundRect(RectF(0f, 0f, w.toFloat(), h.toFloat()), cornerR, cornerR, Path.Direction.CW)
            }
            canvas.clipPath(clipPath)

            val srcW = customBmp.width
            val srcH = customBmp.height
            val targetRatio = w.toFloat() / h.toFloat()
            val srcRatio = srcW.toFloat() / srcH.toFloat()

            val srcRect = if (srcRatio > targetRatio) {
                val newW = (srcH * targetRatio).toInt()
                val left = (srcW - newW) / 2
                Rect(left, 0, left + newW, srcH)
            } else {
                val newH = (srcW / targetRatio).toInt()
                val top = (srcH - newH) / 2
                Rect(0, top, srcW, top + newH)
            }
            val dstRect = Rect(0, 0, w, h)
            val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
            canvas.drawBitmap(customBmp, srcRect, dstRect, bmpPaint)
        } else {
            val photo = repo.curatedPhotos[repo.getCurrentPhotoIndex()]
            drawArtisticPhoto(canvas, w.toFloat(), h.toFloat(), photo.id, photo.dominantColor)
        }

        // Subtle Glass Highlight Border around photo frame
        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#38FFFFFF")
            style = Paint.Style.STROKE
            strokeWidth = dpToPx(context, 1.2f)
        }
        val rect = RectF(1f, 1f, w - 1f, h - 1f)
        canvas.drawRoundRect(rect, cornerR, cornerR, borderPaint)

        // Optional tiny date caption in the corner (minimal, unobtrusive)
        val captionText = if (repo.isUsingCustomPhoto()) "PHOTO" else repo.curatedPhotos[repo.getCurrentPhotoIndex()].dateCaption
        if (captionText.isNotEmpty()) {
            val captionPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#E0FFFFFF")
                textSize = dpToPx(context, 9f)
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                letterSpacing = 0.12f
                setShadowLayer(dpToPx(context, 2f), 0f, 1f, Color.parseColor("#CC000000"))
            }
            val captionX = dpToPx(context, 12f)
            val captionY = h - dpToPx(context, 12f)
            canvas.drawText(captionText, captionX, captionY, captionPaint)
        }

        return bitmap
    }

    private fun drawArtisticPhoto(
        canvas: Canvas,
        w: Float,
        h: Float,
        photoId: String,
        baseColor: Long
    ) {
        val cornerR = 40f
        val path = Path().apply {
            addRoundRect(RectF(0f, 0f, w, h), cornerR, cornerR, Path.Direction.CW)
        }
        canvas.clipPath(path)

        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        when (photoId) {
            "arch_1" -> {
                // Minimal Bauhaus architectural sunset composition
                bgPaint.shader = LinearGradient(0f, 0f, w, h, Color.parseColor("#1E293B"), Color.parseColor("#0F172A"), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, bgPaint)

                // Architectural clean planes & warm lighting
                val warmLight = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    shader = RadialGradient(w * 0.75f, h * 0.25f, w * 0.7f, Color.parseColor("#E6F59E0B"), Color.TRANSPARENT, Shader.TileMode.CLAMP)
                }
                canvas.drawRect(0f, 0f, w, h, warmLight)

                val buildingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.parseColor("#090D16")
                }
                canvas.drawRect(w * 0.15f, h * 0.45f, w * 0.85f, h, buildingPaint)
                val glassPanel = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.parseColor("#3338BDF8")
                }
                canvas.drawRect(w * 0.25f, h * 0.55f, w * 0.75f, h * 0.85f, glassPanel)
            }
            "nature_1" -> {
                // Nordic misty pine forest
                bgPaint.shader = LinearGradient(0f, 0f, 0f, h, Color.parseColor("#061A14"), Color.parseColor("#0B2B22"), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, bgPaint)

                val mistPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    shader = LinearGradient(0f, h * 0.3f, 0f, h * 0.7f, Color.parseColor("#4D38BDF8"), Color.TRANSPARENT, Shader.TileMode.CLAMP)
                }
                canvas.drawRect(0f, 0f, w, h, mistPaint)

                val pinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.parseColor("#030F0C")
                }
                val pinePath = Path().apply {
                    moveTo(w * 0.5f, h * 0.25f)
                    lineTo(w * 0.85f, h)
                    lineTo(w * 0.15f, h)
                    close()
                }
                canvas.drawPath(pinePath, pinePaint)
            }
            "sunset_1" -> {
                // Alpine golden hour
                bgPaint.shader = LinearGradient(0f, 0f, 0f, h, Color.parseColor("#3D1F14"), Color.parseColor("#F59E0B"), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, bgPaint)

                val sunPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.parseColor("#FFFBEB")
                }
                canvas.drawCircle(w * 0.5f, h * 0.5f, w * 0.2f, sunPaint)

                val mountainPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.parseColor("#1A0B05")
                }
                val mountainPath = Path().apply {
                    moveTo(0f, h * 0.65f)
                    lineTo(w * 0.45f, h * 0.38f)
                    lineTo(w * 0.75f, h * 0.52f)
                    lineTo(w, h * 0.42f)
                    lineTo(w, h)
                    lineTo(0f, h)
                    close()
                }
                canvas.drawPath(mountainPath, mountainPaint)
            }
            else -> {
                // Obsidian Glass / Kyoto Zen Garden
                bgPaint.shader = LinearGradient(0f, 0f, w, h, Color.parseColor("#0F172A"), Color.parseColor("#020617"), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, bgPaint)

                val cyanGlow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    shader = RadialGradient(w * 0.3f, h * 0.3f, w * 0.6f, Color.parseColor("#4D38BDF8"), Color.TRANSPARENT, Shader.TileMode.CLAMP)
                }
                canvas.drawRect(0f, 0f, w, h, cyanGlow)

                val goldGlow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    shader = RadialGradient(w * 0.75f, h * 0.75f, w * 0.6f, Color.parseColor("#4DF59E0B"), Color.TRANSPARENT, Shader.TileMode.CLAMP)
                }
                canvas.drawRect(0f, 0f, w, h, goldGlow)
            }
        }
    }

    // -------------------------------------------------------------
    // 4. WORLD CLOCK (Preferred Default: 3×2 cells)
    // -------------------------------------------------------------
    fun renderWorldClockBitmap(
        context: Context,
        widthPx: Int,
        heightPx: Int,
        repo: AuraRepository
    ): Bitmap {
        val w = widthPx.coerceAtLeast(300)
        val h = heightPx.coerceAtLeast(180)
        val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        drawGlassBackground(canvas, w.toFloat(), h.toFloat(), cornerRadius = dpToPx(context, 22f))

        val results = repo.getCityTimeResults() // 4 cities: India, London, New York, Singapore

        val padX = dpToPx(context, 14f)
        val padY = dpToPx(context, 12f)
        val availW = w - (padX * 2)
        val availH = h - (padY * 2)

        // Adaptive arrangement:
        // If very wide (e.g. 4x2 or width/height > 2.2), use 4 columns
        // If tall (width/height < 1.2), use 4 rows
        // Standard 3x2 (width/height between 1.2 and 2.2): clean 2x2 grid
        val isHorizontalFour = (w.toFloat() / h.toFloat() >= 2.3f)
        val isVerticalFour = (w.toFloat() / h.toFloat() < 1.15f)

        if (isHorizontalFour) {
            val itemWidth = availW / 4f
            for (i in results.indices) {
                val left = padX + i * itemWidth
                drawCityItem(context, canvas, results[i], left, padY, itemWidth, availH, isCompact = false)
            }
        } else if (isVerticalFour) {
            val itemHeight = availH / 4f
            for (i in results.indices) {
                val top = padY + i * itemHeight
                drawCityRow(context, canvas, results[i], padX, top, availW, itemHeight)
            }
        } else {
            // Standard 2×2 grid layout (perfect for 3×2 cells)
            val halfW = availW / 2f
            val halfH = availH / 2f

            // Top-Left: India
            drawCityItem(context, canvas, results[0], padX, padY, halfW, halfH, isCompact = true)
            // Top-Right: London
            drawCityItem(context, canvas, results[1], padX + halfW, padY, halfW, halfH, isCompact = true)
            // Bottom-Left: New York
            drawCityItem(context, canvas, results[2], padX, padY + halfH, halfW, halfH, isCompact = true)
            // Bottom-Right: Singapore
            drawCityItem(context, canvas, results[3], padX + halfW, padY + halfH, halfW, halfH, isCompact = true)
        }

        return bitmap
    }

    private fun drawCityItem(
        context: Context,
        canvas: Canvas,
        city: AuraRepository.CityTimeResult,
        left: Float,
        top: Float,
        width: Float,
        height: Float,
        isCompact: Boolean
    ) {
        val cx = left + width / 2f
        val centerY = top + height / 2f

        // City Name Paint
        val cityPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#94A3B8")
            textSize = dpToPx(context, 11f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            letterSpacing = 0.05f
        }

        // Time Paint (Clean, readable digital time)
        val timePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#F8FAFC")
            textSize = dpToPx(context, if (isCompact) 17f else 20f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }

        // Day/Night indicator & Day offset
        val offsetPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#38BDF8")
            textSize = dpToPx(context, 9.5f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }

        val paddingInner = dpToPx(context, 6f)
        val x = left + paddingInner

        // Line 1: City name + optional offset badge (e.g. "-1d")
        val cityY = top + dpToPx(context, 16f)
        canvas.drawText(city.cityName.uppercase(), x, cityY, cityPaint)

        if (city.dayOffsetStr != null) {
            val offsetText = city.dayOffsetStr
            val cityWidth = cityPaint.measureText(city.cityName.uppercase())
            canvas.drawText(offsetText, x + cityWidth + dpToPx(context, 5f), cityY, offsetPaint)
        }

        // Line 2: Time + small day/night symbol
        val timeY = cityY + timePaint.textSize + dpToPx(context, 3f)
        canvas.drawText(city.formattedTime, x, timeY, timePaint)

        // Draw small celestial dot/indicator (Sun = Gold dot, Night = Soft cyan ring)
        val timeWidth = timePaint.measureText(city.formattedTime)
        val dotX = x + timeWidth + dpToPx(context, 8f)
        val dotY = timeY - (timePaint.textSize * 0.35f)

        val glyphPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (city.isDaytime) Color.parseColor("#F59E0B") else Color.parseColor("#38BDF8")
            style = if (city.isDaytime) Paint.Style.FILL else Paint.Style.STROKE
            strokeWidth = dpToPx(context, 1.2f)
        }
        canvas.drawCircle(dotX, dotY, dpToPx(context, 3.2f), glyphPaint)
    }

    private fun drawCityRow(
        context: Context,
        canvas: Canvas,
        city: AuraRepository.CityTimeResult,
        left: Float,
        top: Float,
        width: Float,
        height: Float
    ) {
        val cityPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#94A3B8")
            textSize = dpToPx(context, 12f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }

        val timePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#F8FAFC")
            textSize = dpToPx(context, 14f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
        }

        val offsetPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#38BDF8")
            textSize = dpToPx(context, 10f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }

        val y = top + height * 0.65f
        canvas.drawText(city.cityName, left + dpToPx(context, 4f), y, cityPaint)

        if (city.dayOffsetStr != null) {
            val nameW = cityPaint.measureText(city.cityName)
            canvas.drawText(city.dayOffsetStr, left + nameW + dpToPx(context, 8f), y, offsetPaint)
        }

        canvas.drawText(city.formattedTime, left + width - dpToPx(context, 4f), y, timePaint)
    }

    // -------------------------------------------------------------
    // 5. WEATHER WIDGET (Preferred Default: 3×2 cells)
    // -------------------------------------------------------------
    fun renderWeatherBitmap(
        context: Context,
        widthPx: Int,
        heightPx: Int,
        repo: AuraRepository
    ): Bitmap {
        val w = widthPx.coerceAtLeast(300)
        val h = heightPx.coerceAtLeast(180)
        val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        drawGlassBackground(canvas, w.toFloat(), h.toFloat(), cornerRadius = dpToPx(context, 22f))

        val weather = repo.getWeatherData()

        val padX = dpToPx(context, 16f)
        val padY = dpToPx(context, 14f)
        val availW = w - (padX * 2)
        val availH = h - (padY * 2)

        // Split horizontally: Left 45% = Current Weather, Right 55% = 3-Day Forecast
        val leftWidth = availW * 0.44f
        val rightLeft = padX + leftWidth + dpToPx(context, 8f)
        val rightWidth = availW - leftWidth - dpToPx(context, 8f)

        // --- LEFT SECTION: CURRENT WEATHER ---
        val tempPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#F8FAFC")
            textSize = dpToPx(context, if (h < 300) 28f else 34f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val tempY = padY + tempPaint.textSize
        canvas.drawText("${weather.currentTempC}°", padX, tempY, tempPaint)

        // Small weather icon beside temperature
        val tempW = tempPaint.measureText("${weather.currentTempC}°")
        drawWeatherIconSmall(canvas, padX + tempW + dpToPx(context, 10f), tempY - dpToPx(context, 14f), dpToPx(context, 8f), weather.iconType)

        // Condition text
        val condPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#E2E8F0")
            textSize = dpToPx(context, 11f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val condY = tempY + condPaint.textSize + dpToPx(context, 4f)
        canvas.drawText(weather.condition, padX, condY, condPaint)

        // Today's High & Low
        val hlPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#94A3B8")
            textSize = dpToPx(context, 10.5f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        }
        val hlY = condY + hlPaint.textSize + dpToPx(context, 3f)
        canvas.drawText("H: ${weather.highTempC}°  L: ${weather.lowTempC}°", padX, hlY, hlPaint)

        // --- SUBTLE VERTICAL DIVIDER ---
        val dividerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#1FFFFFFF")
            strokeWidth = dpToPx(context, 1f)
        }
        val divX = padX + leftWidth + dpToPx(context, 3f)
        canvas.drawLine(divX, padY + dpToPx(context, 6f), divX, padY + availH - dpToPx(context, 6f), dividerPaint)

        // --- RIGHT SECTION: 3-DAY FORECAST ---
        val numDays = weather.forecast.size.coerceAtMost(3)
        val colW = rightWidth / numDays.toFloat()

        val dayLabelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#94A3B8")
            textSize = dpToPx(context, 10.5f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }

        val forecastTempPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#F8FAFC")
            textSize = dpToPx(context, 10.5f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }

        val rainProbPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#38BDF8")
            textSize = dpToPx(context, 9f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            textAlign = Paint.Align.CENTER
        }

        for (i in 0 until numDays) {
            val f = weather.forecast[i]
            val cx = rightLeft + (i + 0.5f) * colW

            // 1. Day label (e.g. "Mon")
            val dayY = padY + dpToPx(context, 12f)
            canvas.drawText(f.dayName, cx, dayY, dayLabelPaint)

            // 2. Weather icon
            val iconCenterY = dayY + dpToPx(context, 14f)
            drawWeatherIconSmall(canvas, cx, iconCenterY, dpToPx(context, 6.5f), f.iconType)

            // 3. High & Low temp
            val tempLabelY = iconCenterY + dpToPx(context, 18f)
            canvas.drawText("${f.highTempC}°/${f.lowTempC}°", cx, tempLabelY, forecastTempPaint)

            // 4. Rain probability
            val rainY = tempLabelY + dpToPx(context, 12f)
            canvas.drawText("${f.rainProb}%", cx, rainY, rainProbPaint)
        }

        return bitmap
    }

    private fun drawWeatherIconSmall(
        canvas: Canvas,
        cx: Float,
        cy: Float,
        r: Float,
        type: WeatherIconType
    ) {
        val sunPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#F59E0B")
            style = Paint.Style.FILL
        }

        val cloudPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#CBD5E1")
            style = Paint.Style.FILL
        }

        when (type) {
            WeatherIconType.SUNNY -> {
                canvas.drawCircle(cx, cy, r, sunPaint)
            }
            WeatherIconType.PARTLY_CLOUDY -> {
                // Sun behind cloud
                canvas.drawCircle(cx + r * 0.4f, cy - r * 0.3f, r * 0.7f, sunPaint)
                canvas.drawCircle(cx - r * 0.2f, cy + r * 0.2f, r * 0.65f, cloudPaint)
                canvas.drawCircle(cx + r * 0.3f, cy + r * 0.2f, r * 0.5f, cloudPaint)
            }
            WeatherIconType.RAINY -> {
                canvas.drawCircle(cx, cy - r * 0.2f, r * 0.75f, cloudPaint)
                val rainPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.parseColor("#38BDF8")
                    strokeWidth = 2f
                }
                canvas.drawLine(cx - r * 0.3f, cy + r * 0.6f, cx - r * 0.4f, cy + r * 1.1f, rainPaint)
                canvas.drawLine(cx + r * 0.2f, cy + r * 0.6f, cx + r * 0.1f, cy + r * 1.1f, rainPaint)
            }
            else -> {
                canvas.drawCircle(cx, cy, r * 0.8f, cloudPaint)
            }
        }
    }

    // -------------------------------------------------------------
    // COMMON: Frosted Glass Background with Hairline Specular Border
    // -------------------------------------------------------------
    private fun drawGlassBackground(
        canvas: Canvas,
        w: Float,
        h: Float,
        cornerRadius: Float
    ) {
        val rect = RectF(0f, 0f, w, h)

        // Translucent dark glass fill
        val glassFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(
                0f, 0f, 0f, h,
                Color.parseColor("#331E293B"),
                Color.parseColor("#260F172A"),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawRoundRect(rect, cornerRadius, cornerRadius, glassFillPaint)

        // Subtle specular highlight on top border
        val highlightPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(
                0f, 0f, w, 0f,
                Color.parseColor("#10FFFFFF"),
                Color.parseColor("#44FFFFFF"),
                Shader.TileMode.CLAMP
            )
            style = Paint.Style.STROKE
            strokeWidth = 2.5f
        }
        canvas.drawRoundRect(rect, cornerRadius, cornerRadius, highlightPaint)
    }
}
