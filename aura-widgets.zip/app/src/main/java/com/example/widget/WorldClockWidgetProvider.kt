package com.example.widget

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.RemoteViews
import com.example.MainActivity
import com.example.R
import com.example.data.AuraRepository

class WorldClockWidgetProvider : AppWidgetProvider() {

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val action = intent.action
        if (action == "com.example.ACTION_UPDATE_WORLD_CLOCK" ||
            action == Intent.ACTION_TIME_CHANGED ||
            action == Intent.ACTION_TIMEZONE_CHANGED
        ) {
            updateAll(context)
            scheduleNextTick(context)
        }
    }

    override fun onEnabled(context: Context) {
        super.onEnabled(context)
        scheduleNextTick(context)
    }

    override fun onDisabled(context: Context) {
        super.onDisabled(context)
        cancelTick(context)
    }

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        val repo = AuraRepository.getInstance(context)
        for (appWidgetId in appWidgetIds) {
            val options = appWidgetManager.getAppWidgetOptions(appWidgetId)
            updateWidget(context, appWidgetManager, appWidgetId, options, repo)
        }
        scheduleNextTick(context)
    }

    override fun onAppWidgetOptionsChanged(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetId: Int,
        newOptions: Bundle
    ) {
        val repo = AuraRepository.getInstance(context)
        updateWidget(context, appWidgetManager, appWidgetId, newOptions, repo)
    }

    companion object {
        fun updateAll(context: Context) {
            val appWidgetManager = AppWidgetManager.getInstance(context)
            val ids = appWidgetManager.getAppWidgetIds(
                ComponentName(context, WorldClockWidgetProvider::class.java)
            )
            val repo = AuraRepository.getInstance(context)
            for (id in ids) {
                val options = appWidgetManager.getAppWidgetOptions(id)
                updateWidget(context, appWidgetManager, id, options, repo)
            }
        }

        fun scheduleNextTick(context: Context) {
            try {
                val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager
                val intent = Intent(context, WorldClockWidgetProvider::class.java).apply {
                    action = "com.example.ACTION_UPDATE_WORLD_CLOCK"
                }
                val pendingIntent = PendingIntent.getBroadcast(
                    context,
                    301,
                    intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                val now = System.currentTimeMillis()
                val nextMinute = now + (60000 - (now % 60000))
                alarmManager?.setExactAndAllowWhileIdle(AlarmManager.RTC, nextMinute, pendingIntent)
            } catch (e: Exception) {
                // Ignore
            }
        }

        fun cancelTick(context: Context) {
            try {
                val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager
                val intent = Intent(context, WorldClockWidgetProvider::class.java).apply {
                    action = "com.example.ACTION_UPDATE_WORLD_CLOCK"
                }
                val pendingIntent = PendingIntent.getBroadcast(
                    context,
                    301,
                    intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                alarmManager?.cancel(pendingIntent)
            } catch (e: Exception) {
                // Ignore
            }
        }

        fun updateWidget(
            context: Context,
            appWidgetManager: AppWidgetManager,
            appWidgetId: Int,
            options: Bundle?,
            repo: AuraRepository
        ) {
            // Preferred 3x2 cells: minWidth 180dp, minHeight 110dp
            val minWidthDp = options?.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH) ?: 180
            val minHeightDp = options?.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT) ?: 110

            val widthPx = WidgetRenderer.dpToPx(context, minWidthDp.toFloat().coerceAtLeast(140f)).toInt()
            val heightPx = WidgetRenderer.dpToPx(context, minHeightDp.toFloat().coerceAtLeast(90f)).toInt()

            val bitmap = WidgetRenderer.renderWorldClockBitmap(context, widthPx, heightPx, repo)

            val views = RemoteViews(context.packageName, R.layout.widget_world_clock_layout)
            views.setImageViewBitmap(R.id.widget_world_clock_image, bitmap)

            // Tap action: opens World Clock Studio
            val intent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra("selected_widget_tab", "world_clock")
            }
            val pendingIntent = PendingIntent.getActivity(
                context,
                103,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_world_clock_root, pendingIntent)

            appWidgetManager.updateAppWidget(appWidgetId, views)
        }
    }
}
