package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.example.ui.AuraStudioScreen
import com.example.ui.theme.AuraTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val initialTab = intent?.getStringExtra("selected_widget_tab")

        setContent {
            AuraTheme {
                AuraStudioScreen(initialTab = initialTab)
            }
        }
    }
}
