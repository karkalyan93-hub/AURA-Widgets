package com.example

import com.example.data.AuraRepository
import com.example.model.ClockDialTheme
import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDate

class ExampleUnitTest {

    @Test
    fun testCalendarMondayFirstAndSixWeeks() {
        // August 2026 starts on Saturday (Aug 1 = Saturday -> index 5)
        // 31 days total. 5 + 31 = 36 cells -> requires 6 full rows
        val targetDate = LocalDate.of(2026, 8, 15)
        val firstDay = targetDate.withDayOfMonth(1)
        val startDayOfWeekMondayBased = firstDay.dayOfWeek.value - 1
        val daysInMonth = targetDate.lengthOfMonth()

        assertEquals(5, startDayOfWeekMondayBased) // Saturday is index 5 (0=Mon, 6=Sun)
        assertEquals(31, daysInMonth)

        val totalCells = startDayOfWeekMondayBased + daysInMonth
        val rowsNeeded = if (totalCells > 35) 6 else 5
        assertEquals(6, rowsNeeded)
    }

    @Test
    fun testWidgetSpecsAudit() {
        val specs = AuraRepository.WIDGET_SPECS
        assertEquals(5, specs.size)

        val calendarSpec = specs.first { it.id == "calendar" }
        assertEquals("4×3", calendarSpec.preferredCellSpan)
        assertEquals(250, calendarSpec.minWidthDp)
        assertEquals(180, calendarSpec.minHeightDp)

        val clockSpec = specs.first { it.id == "luxury_clock" }
        assertEquals("2×2", clockSpec.preferredCellSpan)
        assertEquals(110, clockSpec.minWidthDp)
        assertEquals(110, clockSpec.minHeightDp)

        val photoSpec = specs.first { it.id == "photo_frame" }
        assertEquals("2×2", photoSpec.preferredCellSpan)
        assertEquals(110, photoSpec.minWidthDp)
        assertEquals(110, photoSpec.minHeightDp)

        val worldClockSpec = specs.first { it.id == "world_clock" }
        assertEquals("3×2", worldClockSpec.preferredCellSpan)
        assertEquals(180, worldClockSpec.minWidthDp)
        assertEquals(110, worldClockSpec.minHeightDp)

        val weatherSpec = specs.first { it.id == "weather" }
        assertEquals("3×2", weatherSpec.preferredCellSpan)
        assertEquals(180, weatherSpec.minWidthDp)
        assertEquals(110, weatherSpec.minHeightDp)
    }

    @Test
    fun testClockThemesEnum() {
        val themes = ClockDialTheme.values()
        assertTrue(themes.any { it.name == "OBSIDIAN_GOLD" })
        assertTrue(themes.any { it.name == "SAPPHIRE_AZURE" })
        assertTrue(themes.any { it.name == "EMERALD_NOIR" })
        assertTrue(themes.any { it.name == "CHAMPAGNE_TITANIUM" })
    }
}
